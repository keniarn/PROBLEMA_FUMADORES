package com.mycompany.semaforos;

import java.util.concurrent.Semaphore;

public class FumadorFosforos implements Runnable {
    
    private final Semaphore semAgente;
    private final Semaphore semFosforos = new Semaphore(0);
    
    public FumadorFosforos(Semaphore semAgente){
        this.semAgente = semAgente;
    }
    
    public void liberar(){
        semFosforos.release();
    }
    
    @Override
    public void run() {
        try {
            semFosforos.acquire();
            System.out.println("El fumador que tiene fosforos esta armando el cigarro...");
            Thread.sleep(4000);
            System.out.println("El fumador que tiene fosforos esta fumando el cigarro...");
            Thread.sleep(4000);
            System.out.println("El fumador que tiene fosforos apago el cigarro.\n");
            Thread.sleep(2000);
            semAgente.release();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
