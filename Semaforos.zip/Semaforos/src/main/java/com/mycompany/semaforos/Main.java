package com.mycompany.semaforos;

import java.util.concurrent.*;

public class Main {
    
    public static void main(String[] args) {
        
        Semaphore semAgente = new Semaphore(1); //semáforo del agente, que solo permite 1 hilo a la vez
        
        Thread hiloAgente = new Thread(new Agente(semAgente));
        
        hiloAgente.start();
    }
    
}
