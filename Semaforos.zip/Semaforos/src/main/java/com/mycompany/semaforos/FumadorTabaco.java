package com.mycompany.semaforos;

import java.util.concurrent.Semaphore;

public class FumadorTabaco implements Runnable {
    
    private final Semaphore semAgente;
    private final Semaphore semTabaco = new Semaphore(0);
    
    public FumadorTabaco(Semaphore semAgente){
        this.semAgente = semAgente;
    }
    
    public void liberar(){
        semTabaco.release();
    }

    @Override
    public void run() {
        try {
            semTabaco.acquire();
            System.out.println("El fumador que tiene tabaco esta armando el cigarro...");
            Thread.sleep(4000);
            System.out.println("El fumador que tiene tabaco esta fumando el cigarro...");
            Thread.sleep(4000);
            System.out.println("El fumador que tiene tabaco apago el cigarro.\n");
            Thread.sleep(2000);
            semAgente.release();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
    
}
