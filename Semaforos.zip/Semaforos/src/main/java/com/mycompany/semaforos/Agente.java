package com.mycompany.semaforos;
import java.util.concurrent.Semaphore;

public class Agente implements Runnable{
    
    private final Semaphore semAgente; //semáforo del agente, que solo permite 1 hilo a la vez
    private final String[] ingredientes;
    private String[] mesa;
    
    public Agente (Semaphore semAgente){
        this.ingredientes = new String[]{"papel", "tabaco", "fosforos"};
        this.semAgente = semAgente;
    }
    
    @Override
    public void run() { 
        int count = 3;
        while(count>0){
            try {
                semAgente.acquire();

                //La primera tarea del agente será escoger los dos ingredientes que pondrá en la mesa:
                mesa = escogerIngredientes();

                System.out.println("El agente esta escogiendo los ingredientes...");
                Thread.sleep(3000);
                System.out.println("El agente coloca " + mesa[0] + " y " + mesa[1] + " en la mesa.");
                Thread.sleep(4000);

                if("papel".contains(mesa[0]) & "tabaco".contains(mesa[1])){
                    FumadorFosforos fosforos = new FumadorFosforos(semAgente);
                    Thread hiloFosforos = new Thread(fosforos);
                    hiloFosforos.start();
                    fosforos.liberar();
                } else if ("papel".contains(mesa[0]) & "fosforos".contains(mesa[1])){
                    FumadorTabaco tabaco = new FumadorTabaco(semAgente);
                    Thread hiloTabaco = new Thread(tabaco);
                    hiloTabaco.start();
                    tabaco.liberar();
                } else {
                    FumadorPapel papel = new FumadorPapel(semAgente);
                    Thread hiloPapel = new Thread(papel);
                    hiloPapel.start();
                    papel.liberar();
                } 
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } 
            count--;
        }
    }
    
    
    public String[] escogerIngredientes(){
        
        while(true){
            int index = (int) (Math.random()*3);
            int index2 = (int) (Math.random()*3);
            
            if(index != index2){
                if(index > index2){
                    int temp = index;
                    index = index2;
                    index2 = temp;
                }
                
                String[] mesa = {ingredientes[index], ingredientes[index2]}; 
                return mesa; 
            }
        }
    }
}
